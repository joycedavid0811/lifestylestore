

       <?php
        $conn= mysqli_connect("localhost","root","","store");
        $select_query= "SELECT name, email, password, contact, city, address FROM users";
        $select_query_result= mysqli_query($con, $select_query)or die (mysqli_error($conn));
        $name= $_POST['name'];
        $email= $_POST['email'];
        $password= $_POST['password'];
        $contact= $_POST['contact'];
        $city= $_POST['city'];
        $address= $_POST['address'];
        $user_registration_query= "insert into users(name, email, password, contact, city, address)
                values('$name', '$email', '$password', '$contact', '$city', '$address')";
        $user_registration_submit= mysqli_quesry($conn, $user_registration_query)or die(mysqli_error($conn));
        echo "User successfully inserted";
        ?>
        

