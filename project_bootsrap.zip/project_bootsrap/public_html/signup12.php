
<html>
    <head>
        <title>
            Thank you
        </title>
        <link href="newcss.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h2>Thank you for registering</h2>
    </body>
</html>
      


 <?php
       session_start();
        $connect= mysqli_connect("localhost","root","","store");
        if(mysqli_connect_errno($connect))
        {
            echo'Failed to connect';
        }
        $name= $_POST['name'];
        $email= $_POST['email'];
        $password= $_POST['password'];
        $contact= $_POST['contact'];
        $city= $_POST['city'];
        $address= $_POST['address'];
        
        mysqli_query($connect, "INSERT INTO(name, email, password, contact, city, address)
                VALUES('$name', '$email', '$password', '$contact', '$city', '$address')");
        
        if(mysqli_affected_rows($connect)>0)
        {
            
        }
       else {
              echo "Employee Not Added<br />";
              echo mysqli_error($connect);
           }
      
        ?>
        

