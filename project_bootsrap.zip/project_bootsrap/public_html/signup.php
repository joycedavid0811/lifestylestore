

       <?php
        $connect= mysqli_connect("localhost","root","","store");
        if(mysqli_connect_errno($connect))
        {
            echo'Failed to connect';
        }
        $name= $_POST['name'];
        $email= $_POST['email'];
        $password= $_POST['password'];
        $contact= $_POST['contact'];
        $city= $_POST['city'];
        $address= $_POST['address'];
        
        mysqli_query($connect, "INSERT INTO(name, email, password, contact, city, address)
                VALUES('$name', '$email', '$password', '$contact', '$city', '$address')");
        
        if(mysqli_affected_rows($connect)>0)
        {
            echo 'Employee added';
        }
       else {
              echo "Employee Not Added<br />";
              echo mysqli_error($connect);
           }
      
        ?>
        

